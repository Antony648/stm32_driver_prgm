#ifndef __ANTO_GPIO_C_DRIVER_H__
#define __ANTO_GPIO_C_DRIVER_H__

#define PERIPHERAL_START		0x4000 0000
#define RCC								  (PERIPHERAL_START+0X20000)

typedef struct
{
	
}GPIO_port_t;

#endif